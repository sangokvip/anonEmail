document.addEventListener('DOMContentLoaded', () => {
  const emailForm = document.getElementById('emailForm');
  const fileInput = document.getElementById('attachments');
  const fileList = document.getElementById('fileList');
  const resultContainer = document.getElementById('resultContainer');
  const result = document.getElementById('result');
  const closeResultBtn = document.getElementById('closeResultBtn');
  const sendButton = document.getElementById('sendButton');
  
  // 设置年份
  document.getElementById('current-year').textContent = new Date().getFullYear();

  // 处理文件选择
  fileInput.addEventListener('change', () => {
    fileList.innerHTML = '';
    const files = Array.from(fileInput.files);

    if (files.length > 0) {
      files.forEach(file => {
        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';
        
        const fileName = document.createElement('span');
        fileName.textContent = `${file.name} (${formatFileSize(file.size)})`;
        
        const removeBtn = document.createElement('button');
        removeBtn.innerHTML = '&times;';
        removeBtn.title = '移除附件';
        
        // 这个功能是为前端展示，由于HTML文件输入的限制，
        // 我们无法移除已选择的单个文件，但可以提示用户重新选择
        removeBtn.addEventListener('click', () => {
          fileItem.remove();
          if (fileList.children.length === 0) {
            alert('附件已全部移除，您需要重新选择文件。');
            fileInput.value = '';
          }
        });
        
        fileItem.appendChild(fileName);
        fileItem.appendChild(removeBtn);
        fileList.appendChild(fileItem);
      });
    }
  });

  // 提交表单
  emailForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    try {
      sendButton.disabled = true;
      sendButton.textContent = '发送中...';
      
      const formData = new FormData(emailForm);
      formData.append('domain', 'soeasy.mom'); // 添加固定域名
      
      // 这里替换为您的 Cloudflare Worker API 地址
      const apiUrl = 'https://email-api.your-domain.workers.dev/send-email';
      
      const response = await fetch(apiUrl, {
        method: 'POST',
        body: formData
      });
      
      const data = await response.json();
      
      if (data.success) {
        result.className = 'result success';
        result.innerHTML = `
          <h3>邮件发送成功！</h3>
          <p>邮件已从 ${formData.get('prefix')}@soeasy.mom 发送至 ${formData.get('to')}</p>
        `;
        // 清空表单
        emailForm.reset();
        fileList.innerHTML = '';
      } else {
        result.className = 'result error';
        result.innerHTML = `
          <h3>邮件发送失败</h3>
          <p>错误信息: ${data.error}</p>
        `;
      }
    } catch (error) {
      result.className = 'result error';
      result.innerHTML = `
        <h3>发送过程中出错</h3>
        <p>错误信息: ${error.message}</p>
      `;
    } finally {
      resultContainer.classList.remove('hidden');
      sendButton.disabled = false;
      sendButton.textContent = '发送邮件';
    }
  });

  // 关闭结果提示
  closeResultBtn.addEventListener('click', () => {
    resultContainer.classList.add('hidden');
  });

  // 文件大小格式化
  function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }
}); 
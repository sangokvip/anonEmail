# Cloudflare Pages 和 Workers 部署指南

本项目包含一个自定义邮件发送系统，使用 Cloudflare Pages 部署前端，Cloudflare Workers 部署后端API。

## 项目结构

```
cloudflare-deployment/
├── frontend/            # 前端静态文件，部署到 Cloudflare Pages
│   ├── index.html
│   ├── css/
│   ├── js/
│   └── _redirects       # Cloudflare Pages 重定向配置
│
└── api/                 # 后端API，部署到 Cloudflare Workers
    ├── worker.js        # Worker 主文件
    └── wrangler.toml    # Worker 配置文件
```

## 部署步骤

### 1. 部署 Cloudflare Worker (后端API)

1. 安装 Wrangler CLI（如果尚未安装）:

```bash
npm install -g wrangler
```

2. 登录到您的 Cloudflare 账户:

```bash
wrangler login
```

3. 进入 api 目录:

```bash
cd cloudflare-deployment/api
```

4. 创建环境变量（存储 Resend API 密钥）:

```bash
wrangler secret put RESEND_API_KEY
```
然后输入您的 Resend API 密钥: `re_26igZaRn_HggyZihfob6Wt2QG2iiUB44V`

5. 发布 Worker:

```bash
wrangler publish
```

6. 发布成功后，记下您的 Worker 网址，通常是 `https://email-api.your-username.workers.dev`

### 2. 更新前端代码中的 API 地址

1. 编辑 `frontend/js/script.js` 文件
2. 找到 `apiUrl` 变量并更新为您的 Worker URL:

```javascript
const apiUrl = 'https://email-api.your-username.workers.dev/send-email';
```

### 3. 部署前端到 Cloudflare Pages

#### 方法一：通过 Cloudflare Dashboard (推荐)

1. 登录 [Cloudflare Dashboard](https://dash.cloudflare.com/)
2. 选择 "Pages"
3. 点击 "创建项目"
4. 选择 "直接上传" 选项
5. 将 `frontend` 目录中的内容拖放到上传区域
6. 命名您的项目并点击 "部署站点"

#### 方法二：通过 GitHub 仓库

1. 将代码推送到 GitHub 仓库
2. 登录 [Cloudflare Dashboard](https://dash.cloudflare.com/)
3. 选择 "Pages"
4. 点击 "创建项目"
5. 选择 "连接到 Git"
6. 选择您的 GitHub 仓库
7. 配置构建设置:
   - 构建命令: 留空（因为是静态文件）
   - 构建输出目录: `cloudflare-deployment/frontend`
8. 点击 "保存并部署"

### 4. 配置自定义域名 (可选)

如果您希望使用自定义域名:

1. 在 Cloudflare Dashboard 中选择您的 Pages 项目
2. 点击 "自定义域"
3. 输入您的域名并按照说明进行验证和配置

## 测试部署

1. 访问您的 Cloudflare Pages URL（例如 `https://your-project.pages.dev`）
2. 填写邮件表单进行测试发送

## 注意事项

1. **CORS 设置**: 在生产环境中，应将 Worker 中的 CORS 设置更改为只允许您的域名，而不是 '*'
2. **安全性考虑**: 
   - 确保 Resend API 密钥仅存储在 Cloudflare 的环境变量中
   - 考虑添加速率限制以防止滥用
3. **域名验证**: 确保 `soeasy.mom` 已在 Resend 平台上验证，否则发送可能会失败 
// Cloudflare Worker for Email Sending API

import { Resend } from 'resend';

// 初始化Resend客户端 - 您需要在Cloudflare的环境变量中设置此密钥
const resend = new Resend(RESEND_API_KEY);

// 处理跨域请求的headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*', // 在生产环境中应该限制为您的域名
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

// 处理OPTIONS请求 (预检请求)
function handleOptions(request) {
  return new Response(null, {
    headers: corsHeaders,
    status: 204,
  });
}

// 主处理函数
async function handleRequest(request) {
  // 处理预检请求
  if (request.method === 'OPTIONS') {
    return handleOptions(request);
  }

  if (request.method !== 'POST') {
    return new Response(JSON.stringify({ success: false, error: '只支持POST请求' }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 405,
    });
  }

  try {
    // 解析multipart/form-data请求
    const formData = await request.formData();
    const prefix = formData.get('prefix');
    const domain = formData.get('domain');
    const to = formData.get('to');
    const subject = formData.get('subject');
    const content = formData.get('content');

    // 检查必填项
    if (!prefix || !domain || !to || !subject || !content) {
      return new Response(
        JSON.stringify({ success: false, error: '所有字段都是必填的' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400,
        }
      );
    }

    // 构建发件人地址
    const from = `${prefix} <${prefix}@${domain}>`;
    
    // 获取附件（如果有）
    let attachments = [];
    
    // 检查是否有附件
    if (formData.has('attachments')) {
      const files = formData.getAll('attachments');
      
      for (const file of files) {
        if (file.size > 0) {
          const fileArrayBuffer = await file.arrayBuffer();
          const fileBase64 = btoa(String.fromCharCode(...new Uint8Array(fileArrayBuffer)));
          
          attachments.push({
            filename: file.name,
            content: fileBase64
          });
        }
      }
    }

    // 发送邮件
    const emailData = {
      from,
      to: [to],
      subject,
      html: content,
    };

    // 如果有附件，添加到请求中
    if (attachments.length > 0) {
      emailData.attachments = attachments;
    }

    const { data, error } = await resend.emails.send(emailData);

    if (error) {
      return new Response(
        JSON.stringify({ success: false, error: error.message }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 500,
        }
      );
    }

    return new Response(
      JSON.stringify({ success: true, data }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );

  } catch (error) {
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
}

// 注册事件监听器
addEventListener('fetch', (event) => {
  event.respondWith(handleRequest(event.request));
}); 